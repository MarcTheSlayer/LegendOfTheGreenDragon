################################
# Module: lodge_incentives.php #
################################

Hi,

Thanks for trying my module.

You may find that it will miss out one or two modules even though they're installed and active.
I don't know why this is, but if you go to each module's settings page and click save and then
select 'reset' on the 'lodge_incentives' settings page and click save, it will catch them this
time around. Edit the textarea box info to your liking and then save again, though make sure
'reset' is set to NO. :)

This 'reset' option is basically just a quick help to fill the textarea box. The info comes from
hard coded text inside the module file. You don't have to use the 'reset' option. Enter whatever
you want.

**IMPORTANT**
This module allows you to change the default 100 points you get for a $1 donation.
However, the default 100 value is hard coded in various hooks, and although this
module hooks into and alters the value, any other modules that use these various
hooks will use the default 100.

-Marc :)