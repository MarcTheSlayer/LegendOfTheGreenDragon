###################
#### IMPORTANT ####
###################

You must carry out at least the first 4 of these core file edits for this module to work.
If you don't have the valhalla module installed then ignore the last one. :)


###################
#
#-----[ OPEN ]-----
#
bio.php

#
#-----[ FIND ]-----
#
  modulehook("biotop", $target);

#
#-----[ REPLACE WITH ]-----
#
//
// Start Changes for Who's There module.
//
  $target = modulehook("biotop", $target);
//  modulehook("biotop", $target);
//
// End Changes for Who's There module.
//

###################
#
#-----[ OPEN ]-----
#
list.php

#
#-----[ FIND ]-----
#
for($i=0;$i<$max;$i++){
	$row = db_fetch_assoc($result);

#
#-----[ REPLACE WITH ]-----
#
//
// Start Changes for Who's There module.
//
$rows = array();
$i = 0;
while( $row = db_fetch_assoc($result) )
{
	foreach( $row as $key => $value )
	{
		$rows[$i][$key] = $value;
	}
	$i++;
}
db_free_result($result);
$rows = modulehook('warriorlist', $rows);

for($i=0;$i<$max;$i++){
//	$row = db_fetch_assoc($result);
	$row = $rows[$i];
//
// End Changes for Who's There module.
//

###################
#
#-----[ OPEN ]-----
#
village.php

#
#-----[ FIND ]-----
#
		output($texts['talk']);
		tlschema();
		commentdisplay("",$texts['section'],"Speak",25,$texts['sayline'], $schemas['sayline']);
		
#
#-----[ REPLACE WITH ]-----
#
		//
		// Start Changes for Who's There module.
		//
		//output($texts['talk']);
		//tlschema();
		//commentdisplay("",$texts['section'],"Speak",25,$texts['sayline'], $schemas['sayline']);
		
		$talk = $texts['talk'];
		tlschema();
		commentdisplay($talk,$texts['section'],"Speak",25,$texts['sayline'], $schemas['sayline']);

		//
		// End Changes for Who's There module.
		//

###################
#
#-----[ OPEN ]-----
#
lib/commentary.php

#
#-----[ FIND ]-----
#
	if ($intro) output($intro);

#
#-----[ REPLACE WITH ]-----
#
	//
	// Start Changes for Who's There module.
	//
	$args = modulehook('sectionname', array('section'=>$section));
	$section = $args['section'];

	if ($intro) output('%s',$intro);
	//if ($intro) output($intro);
	//
	// End Changes for Who's There module.
	//

###################
#
#-----[ OPEN ]-----
#
modules/valhalla.php

#
#-----[ FIND ]-----
#
viewcommentary("valhalla","softly speaks",25,"softly speaks");

#
#-----[ REPLACE WITH ]-----
#
//
// Start Changes for Who's There module.
//
commentdisplay('','valhalla','softly speaks',25,'softly speaks'); 
//viewcommentary("valhalla","softly speaks",25,"softly speaks");
//
// End Changes for Who's There module.
//

#
#-----[ SAVE/CLOSE ALL ]-----
#