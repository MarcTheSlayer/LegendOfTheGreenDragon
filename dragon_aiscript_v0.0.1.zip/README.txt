// This is just a basic AI script for the Dragon.
//
// Check to see if the 'potions' module is active and then check to see
// if player has healing potions. If so then there's a chance the Dragon
// Might get one and regenerate to full health. :)
//
// Copy the below code and paste into the Dragon AI box.

global $badguy;
if( !isset($badguy['spellpoints']) )
{
	$badguy['spellpoints'] = TRUE;
	// Dragon's maxhealth is not set, so do that here.
	$badguy['maxhealth'] = $badguy['creaturehealth'];
	if( is_module_active('potions') )
	{
		global $session;
		$sql = "SELECT value FROM " . db_prefix('module_userprefs') . " WHERE modulename = 'potions' AND setting = 'potion' AND value > 0 AND userid = '" . $session['user']['acctid'] . "'";
		$result = db_query($sql);
    	$row = db_fetch_assoc($result);
		$badguy['spellpoints'] = $row['value'];
	}
}
if( $badguy['creaturehealth'] <= ($badguy['maxhealth']-10) && $badguy['spellpoints'] >= 1 && rand(1,3) == 1 )
{
	global $session;
	$badguy['spellpoints']--;
	$diff = $badguy['maxhealth'] - $badguy['creaturehealth'];
	$badguy['creaturehealth'] = $badguy['maxhealth'];
	db_query("UPDATE " . db_prefix('module_userprefs') . " SET value = value - 1 WHERE modulename = 'potions' AND setting = 'potion' AND userid = '" . $session['user']['acctid'] . "'");
	output('`@The Green Dragon `%regenerates for %s health.`0', $diff);
	rawoutput('<br /><br />');
	output('`$Oh NO!!! `2One of your `%healing potions `2fell out of your pouch and `@The Green Dragon `2gobbled it up and is back to full health!`0');
	rawoutput('<br /><br />');
}