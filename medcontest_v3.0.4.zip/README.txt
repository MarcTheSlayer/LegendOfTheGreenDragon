Please make sure to copy the files to the correct directories.


root/images/med_bomb.gif
root/images/med_clear.gif
root/images/med_coin.gif
root/images/med_ducky.gif
root/images/med_egg.gif
root/images/med_lollipop.gif
root/images/med_m-m.gif
root/images/med_pizza.gif
root/images/med_taco.gif

root/modules/medcontest.php

root/modules/medcontest/medcontest_reset.php
root/modules/medcontest/medcontest_timeleft.php

root/modules/medcontest/dohook/charstats.php
root/modules/medcontest/dohook/changesetting.php
root/modules/medcontest/dohook/everyhit.php
root/modules/medcontest/dohook/index.php
root/modules/medcontest/dohook/newday.php
root/modules/medcontest/dohook/pvploss.php
root/modules/medcontest/dohook/pvpwin.php
root/modules/medcontest/dohook/village.php
root/modules/medcontest/dohook/village-desc.php

root/modules/medcontest/run/case_.php
root/modules/medcontest/run/case_entercontest.php
root/modules/medcontest/run/case_reset.php
root/modules/medcontest/run/case_turnin.php

